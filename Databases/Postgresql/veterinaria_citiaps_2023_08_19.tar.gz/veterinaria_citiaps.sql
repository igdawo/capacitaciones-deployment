--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Debian 14.5-1.pgdg110+1)
-- Dumped by pg_dump version 15.3

-- Started on 2023-08-19 01:01:28

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: alan
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO alan;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 210 (class 1259 OID 27457)
-- Name: dueno; Type: TABLE; Schema: public; Owner: alan
--

CREATE TABLE public.dueno (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    edad integer NOT NULL,
    sexo character varying(255) NOT NULL
);


ALTER TABLE public.dueno OWNER TO alan;

--
-- TOC entry 209 (class 1259 OID 27456)
-- Name: dueno_id_seq; Type: SEQUENCE; Schema: public; Owner: alan
--

CREATE SEQUENCE public.dueno_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dueno_id_seq OWNER TO alan;

--
-- TOC entry 3337 (class 0 OID 0)
-- Dependencies: 209
-- Name: dueno_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alan
--

ALTER SEQUENCE public.dueno_id_seq OWNED BY public.dueno.id;


--
-- TOC entry 212 (class 1259 OID 27466)
-- Name: perro; Type: TABLE; Schema: public; Owner: alan
--

CREATE TABLE public.perro (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    raza character varying(255) NOT NULL,
    color character varying(255) NOT NULL,
    edad smallint NOT NULL,
    dueno_id integer NOT NULL
);


ALTER TABLE public.perro OWNER TO alan;

--
-- TOC entry 211 (class 1259 OID 27465)
-- Name: perro_id_seq; Type: SEQUENCE; Schema: public; Owner: alan
--

CREATE SEQUENCE public.perro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.perro_id_seq OWNER TO alan;

--
-- TOC entry 3338 (class 0 OID 0)
-- Dependencies: 211
-- Name: perro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alan
--

ALTER SEQUENCE public.perro_id_seq OWNED BY public.perro.id;


--
-- TOC entry 214 (class 1259 OID 27475)
-- Name: vacuna; Type: TABLE; Schema: public; Owner: alan
--

CREATE TABLE public.vacuna (
    id integer NOT NULL,
    fecha date,
    nombre_vacuna character varying(255),
    perro_id integer NOT NULL
);


ALTER TABLE public.vacuna OWNER TO alan;

--
-- TOC entry 213 (class 1259 OID 27474)
-- Name: vacuna_id_seq; Type: SEQUENCE; Schema: public; Owner: alan
--

CREATE SEQUENCE public.vacuna_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vacuna_id_seq OWNER TO alan;

--
-- TOC entry 3339 (class 0 OID 0)
-- Dependencies: 213
-- Name: vacuna_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alan
--

ALTER SEQUENCE public.vacuna_id_seq OWNED BY public.vacuna.id;


--
-- TOC entry 3177 (class 2604 OID 27460)
-- Name: dueno id; Type: DEFAULT; Schema: public; Owner: alan
--

ALTER TABLE ONLY public.dueno ALTER COLUMN id SET DEFAULT nextval('public.dueno_id_seq'::regclass);


--
-- TOC entry 3178 (class 2604 OID 27469)
-- Name: perro id; Type: DEFAULT; Schema: public; Owner: alan
--

ALTER TABLE ONLY public.perro ALTER COLUMN id SET DEFAULT nextval('public.perro_id_seq'::regclass);


--
-- TOC entry 3179 (class 2604 OID 27478)
-- Name: vacuna id; Type: DEFAULT; Schema: public; Owner: alan
--

ALTER TABLE ONLY public.vacuna ALTER COLUMN id SET DEFAULT nextval('public.vacuna_id_seq'::regclass);


--
-- TOC entry 3326 (class 0 OID 27457)
-- Dependencies: 210
-- Data for Name: dueno; Type: TABLE DATA; Schema: public; Owner: alan
--

INSERT INTO public.dueno VALUES (1, 'Pedro', 21, 'M');
INSERT INTO public.dueno VALUES (2, 'Camila', 26, 'M');
INSERT INTO public.dueno VALUES (3, 'Juan', 31, 'M');
INSERT INTO public.dueno VALUES (4, 'Esteban', 53, 'M');
INSERT INTO public.dueno VALUES (5, 'Paola', 66, 'F');


--
-- TOC entry 3328 (class 0 OID 27466)
-- Dependencies: 212
-- Data for Name: perro; Type: TABLE DATA; Schema: public; Owner: alan
--

INSERT INTO public.perro VALUES (1, 'Snop', 'Basset', 'Cafe-Blanco', 2, 3);
INSERT INTO public.perro VALUES (3, 'Snoopy', 'Terranova', 'Cafe', 2, 4);
INSERT INTO public.perro VALUES (4, 'Pelos', 'Labrador', 'Negro-Cafe', 4, 2);
INSERT INTO public.perro VALUES (5, 'Feliz', 'Boxer', 'Negro', 5, 5);
INSERT INTO public.perro VALUES (2, 'Max', 'Schnauzer', 'Gris', 1, 5);


--
-- TOC entry 3330 (class 0 OID 27475)
-- Dependencies: 214
-- Data for Name: vacuna; Type: TABLE DATA; Schema: public; Owner: alan
--

INSERT INTO public.vacuna VALUES (4, '2023-03-22', 'Sextuple', 5);
INSERT INTO public.vacuna VALUES (1, '2022-08-12', 'Antirrabica', 1);
INSERT INTO public.vacuna VALUES (2, '2019-08-01', 'Sextuple', 2);
INSERT INTO public.vacuna VALUES (5, '2020-12-30', 'Antirrabica', 3);
INSERT INTO public.vacuna VALUES (3, '2022-03-22', 'Octuple2019', 4);


--
-- TOC entry 3340 (class 0 OID 0)
-- Dependencies: 209
-- Name: dueno_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alan
--

SELECT pg_catalog.setval('public.dueno_id_seq', 5, true);


--
-- TOC entry 3341 (class 0 OID 0)
-- Dependencies: 211
-- Name: perro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alan
--

SELECT pg_catalog.setval('public.perro_id_seq', 6, true);


--
-- TOC entry 3342 (class 0 OID 0)
-- Dependencies: 213
-- Name: vacuna_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alan
--

SELECT pg_catalog.setval('public.vacuna_id_seq', 6, true);


--
-- TOC entry 3181 (class 2606 OID 27464)
-- Name: dueno dueno_pkey; Type: CONSTRAINT; Schema: public; Owner: alan
--

ALTER TABLE ONLY public.dueno
    ADD CONSTRAINT dueno_pkey PRIMARY KEY (id);


--
-- TOC entry 3183 (class 2606 OID 27473)
-- Name: perro perro_pkey; Type: CONSTRAINT; Schema: public; Owner: alan
--

ALTER TABLE ONLY public.perro
    ADD CONSTRAINT perro_pkey PRIMARY KEY (id);


--
-- TOC entry 3185 (class 2606 OID 27480)
-- Name: vacuna vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: alan
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT vacuna_pkey PRIMARY KEY (id);


--
-- TOC entry 3336 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: alan
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2023-08-19 01:01:28

--
-- PostgreSQL database dump complete
--

