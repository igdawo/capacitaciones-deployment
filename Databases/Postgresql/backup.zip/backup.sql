--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Dueño; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Dueño" (
    id integer NOT NULL,
    "Edad" integer NOT NULL,
    "Nombre" character varying NOT NULL,
    "Sexo" character varying NOT NULL
);


ALTER TABLE public."Dueño" OWNER TO postgres;

--
-- Name: Perro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Perro" (
    id integer NOT NULL,
    "Edad" integer NOT NULL,
    "fk-Dueño" integer NOT NULL,
    "Nombre" character varying NOT NULL,
    "Raza" character varying NOT NULL,
    "Color" character varying NOT NULL
);


ALTER TABLE public."Perro" OWNER TO postgres;

--
-- Name: Vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Vacuna" (
    id integer NOT NULL,
    "Fecha" date NOT NULL,
    "fk-Perro" integer NOT NULL,
    "NombreVacuna" character varying NOT NULL
);


ALTER TABLE public."Vacuna" OWNER TO postgres;

--
-- Data for Name: Dueño; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Dueño" (id, "Edad", "Nombre", "Sexo") FROM stdin;
2	32	Ana	Femenino
1	25	Felipe	Masculino
\.


--
-- Data for Name: Perro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Perro" (id, "Edad", "fk-Dueño", "Nombre", "Raza", "Color") FROM stdin;
4	0	2	Fea	Kiltro	Negro
3	1	2	Hallie	Kiltro	Cafe claro
2	3	1	Martina	Kiltro	Cafe
1	2	1	Negrita	Kiltro	Negro
\.


--
-- Data for Name: Vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Vacuna" (id, "Fecha", "fk-Perro", "NombreVacuna") FROM stdin;
5	2023-08-15	4	RRNN
4	2023-08-15	4	DHPP
3	2023-08-15	3	DHPP
2	2023-08-16	2	Rabia
1	2023-08-16	1	Rabia
\.


--
-- Name: Dueño Dueño_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Dueño"
    ADD CONSTRAINT "Dueño_pkey" PRIMARY KEY (id);


--
-- Name: Perro Perro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Perro"
    ADD CONSTRAINT "Perro_pkey" PRIMARY KEY (id);


--
-- Name: Vacuna Vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vacuna"
    ADD CONSTRAINT "Vacuna_pkey" PRIMARY KEY (id);


--
-- Name: Perro Perro_fk-Dueño_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Perro"
    ADD CONSTRAINT "Perro_fk-Dueño_fkey" FOREIGN KEY ("fk-Dueño") REFERENCES public."Dueño"(id) NOT VALID;


--
-- Name: Vacuna fk-Perro; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vacuna"
    ADD CONSTRAINT "fk-Perro" FOREIGN KEY ("fk-Perro") REFERENCES public."Perro"(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

