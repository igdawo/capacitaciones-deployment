--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE veterinaria_citiaps;
--
-- Name: veterinaria_citiaps; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE veterinaria_citiaps WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Chile.1252';


ALTER DATABASE veterinaria_citiaps OWNER TO postgres;

\connect veterinaria_citiaps

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: duenos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.duenos (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    edad integer NOT NULL,
    sexo character varying(20) NOT NULL
);


ALTER TABLE public.duenos OWNER TO postgres;

--
-- Name: duenos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.duenos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.duenos_id_seq OWNER TO postgres;

--
-- Name: duenos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.duenos_id_seq OWNED BY public.duenos.id;


--
-- Name: perros; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.perros (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    raza character varying(50) NOT NULL,
    color character varying(50) NOT NULL,
    edad integer NOT NULL,
    dueno_id integer NOT NULL
);


ALTER TABLE public.perros OWNER TO postgres;

--
-- Name: perros_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.perros_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.perros_id_seq OWNER TO postgres;

--
-- Name: perros_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.perros_id_seq OWNED BY public.perros.id;


--
-- Name: vacunas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vacunas (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    fecha date NOT NULL,
    perro_id integer NOT NULL
);


ALTER TABLE public.vacunas OWNER TO postgres;

--
-- Name: vacunas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vacunas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vacunas_id_seq OWNER TO postgres;

--
-- Name: vacunas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vacunas_id_seq OWNED BY public.vacunas.id;


--
-- Name: duenos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.duenos ALTER COLUMN id SET DEFAULT nextval('public.duenos_id_seq'::regclass);


--
-- Name: perros id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perros ALTER COLUMN id SET DEFAULT nextval('public.perros_id_seq'::regclass);


--
-- Name: vacunas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacunas ALTER COLUMN id SET DEFAULT nextval('public.vacunas_id_seq'::regclass);


--
-- Data for Name: duenos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.duenos (id, nombre, edad, sexo) FROM stdin;
\.
COPY public.duenos (id, nombre, edad, sexo) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: perros; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.perros (id, nombre, raza, color, edad, dueno_id) FROM stdin;
\.
COPY public.perros (id, nombre, raza, color, edad, dueno_id) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: vacunas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vacunas (id, nombre, fecha, perro_id) FROM stdin;
\.
COPY public.vacunas (id, nombre, fecha, perro_id) FROM '$$PATH$$/3341.dat';

--
-- Name: duenos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.duenos_id_seq', 5, true);


--
-- Name: perros_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.perros_id_seq', 6, true);


--
-- Name: vacunas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vacunas_id_seq', 9, true);


--
-- Name: duenos duenos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.duenos
    ADD CONSTRAINT duenos_pkey PRIMARY KEY (id);


--
-- Name: perros perros_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perros
    ADD CONSTRAINT perros_pkey PRIMARY KEY (id);


--
-- Name: vacunas vacunas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacunas
    ADD CONSTRAINT vacunas_pkey PRIMARY KEY (id);


--
-- Name: perros perros_dueno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perros
    ADD CONSTRAINT perros_dueno_id_fkey FOREIGN KEY (dueno_id) REFERENCES public.duenos(id);


--
-- Name: vacunas vacunas_perro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacunas
    ADD CONSTRAINT vacunas_perro_id_fkey FOREIGN KEY (perro_id) REFERENCES public.perros(id);


--
-- PostgreSQL database dump complete
--

