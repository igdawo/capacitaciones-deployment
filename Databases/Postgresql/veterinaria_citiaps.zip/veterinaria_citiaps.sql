--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Color; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Color" (
    id_color integer NOT NULL,
    des_color text NOT NULL
);


ALTER TABLE public."Color" OWNER TO postgres;

--
-- Name: Dueño; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Dueño" (
    "id_dueño" integer NOT NULL,
    nombre character varying(400),
    edad integer,
    id_sexo integer
);


ALTER TABLE public."Dueño" OWNER TO postgres;

--
-- Name: Perro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Perro" (
    id_perro integer NOT NULL,
    nombre text,
    id_raza integer,
    id_color integer,
    edad text,
    "id_dueño" integer NOT NULL
);


ALTER TABLE public."Perro" OWNER TO postgres;

--
-- Name: Raza; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Raza" (
    id_raza integer NOT NULL,
    des_raza text NOT NULL
);


ALTER TABLE public."Raza" OWNER TO postgres;

--
-- Name: Sexo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sexo" (
    id_sexo integer NOT NULL,
    des_sexo character varying(200)
);


ALTER TABLE public."Sexo" OWNER TO postgres;

--
-- Name: Vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Vacuna" (
    id_vacuna integer NOT NULL,
    des_vacuna character varying(300) NOT NULL
);


ALTER TABLE public."Vacuna" OWNER TO postgres;

--
-- Name: Vacuna_perro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Vacuna_perro" (
    id_vacuna_perro integer NOT NULL,
    fecha date,
    id_vacuna integer,
    id_perro integer NOT NULL
);


ALTER TABLE public."Vacuna_perro" OWNER TO postgres;

--
-- Data for Name: Color; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Color" (id_color, des_color) FROM stdin;
1	Cafe
2	Negro
3	Blanco
4	Naranjo
5	Atigrado
\.


--
-- Data for Name: Dueño; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Dueño" ("id_dueño", nombre, edad, id_sexo) FROM stdin;
1	Juan Villegas	36	1
2	Paz Pacheco	32	2
3	Julia Andrade	22	3
4	Miguel Astorga	57	1
5	Luisa Garay	16	2
\.


--
-- Data for Name: Perro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Perro" (id_perro, nombre, id_raza, id_color, edad, "id_dueño") FROM stdin;
1	Daina	3	3	4	1
2	Luli	1	3	16	4
3	Akira	2	1	3	2
4	Manchita	3	5	4	3
5	Bobby	4	2	12	5
\.


--
-- Data for Name: Raza; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Raza" (id_raza, des_raza) FROM stdin;
1	Poodle
2	San Bernardo
3	Quiltro
4	Labrador
5	Pastor Aleman
\.


--
-- Data for Name: Sexo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Sexo" (id_sexo, des_sexo) FROM stdin;
1	Hombre
2	Mujer
3	Prefiero no decirlo
\.


--
-- Data for Name: Vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Vacuna" (id_vacuna, des_vacuna) FROM stdin;
1	Vacuna contra la rabia
2	Vacuna contra el parvovirus
3	Vacuna DHPP Distemper, Hepatitis, Parainfluenza, Parvovirus
4	Vacuna contra leptospirosis
5	Vacuna contra la tos de las perreras (Bordetella)
\.


--
-- Data for Name: Vacuna_perro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Vacuna_perro" (id_vacuna_perro, fecha, id_vacuna, id_perro) FROM stdin;
1	2023-08-13	3	3
2	2023-08-13	4	3
3	2023-07-20	1	3
4	2023-07-20	4	3
5	2023-06-15	2	1
6	2023-08-01	3	5
7	2023-07-05	4	2
\.


--
-- Name: Color Color_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Color"
    ADD CONSTRAINT "Color_pkey" PRIMARY KEY (id_color);


--
-- Name: Dueño Dueño_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Dueño"
    ADD CONSTRAINT "Dueño_pkey" PRIMARY KEY ("id_dueño");


--
-- Name: Vacuna Nombre_vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vacuna"
    ADD CONSTRAINT "Nombre_vacuna_pkey" PRIMARY KEY (id_vacuna);


--
-- Name: Perro Perro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Perro"
    ADD CONSTRAINT "Perro_pkey" PRIMARY KEY (id_perro);


--
-- Name: Raza Raza_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Raza"
    ADD CONSTRAINT "Raza_pkey" PRIMARY KEY (id_raza);


--
-- Name: Sexo Sexo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sexo"
    ADD CONSTRAINT "Sexo_pkey" PRIMARY KEY (id_sexo);


--
-- Name: Vacuna_perro Vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vacuna_perro"
    ADD CONSTRAINT "Vacuna_pkey" PRIMARY KEY (id_vacuna_perro);


--
-- Name: Perro Color; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Perro"
    ADD CONSTRAINT "Color" FOREIGN KEY (id_color) REFERENCES public."Color"(id_color) NOT VALID;


--
-- Name: Perro Dueño; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Perro"
    ADD CONSTRAINT "Dueño" FOREIGN KEY ("id_dueño") REFERENCES public."Dueño"("id_dueño") NOT VALID;


--
-- Name: Vacuna_perro Perro; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vacuna_perro"
    ADD CONSTRAINT "Perro" FOREIGN KEY (id_perro) REFERENCES public."Perro"(id_perro) NOT VALID;


--
-- Name: Perro Raza; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Perro"
    ADD CONSTRAINT "Raza" FOREIGN KEY (id_raza) REFERENCES public."Raza"(id_raza) NOT VALID;


--
-- Name: Dueño sexo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Dueño"
    ADD CONSTRAINT sexo FOREIGN KEY (id_sexo) REFERENCES public."Sexo"(id_sexo) NOT VALID;


--
-- Name: Vacuna_perro vacuna; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vacuna_perro"
    ADD CONSTRAINT vacuna FOREIGN KEY (id_vacuna) REFERENCES public."Vacuna"(id_vacuna) NOT VALID;


--
-- PostgreSQL database dump complete
--

