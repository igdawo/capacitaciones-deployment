--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

-- Started on 2023-08-14 23:53:44 -04

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 16477)
-- Name: duenio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.duenio (
    id integer NOT NULL,
    nombre character varying(255),
    edad integer,
    sexo character varying(20)
);


ALTER TABLE public.duenio OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16476)
-- Name: duenio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.duenio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.duenio_id_seq OWNER TO postgres;

--
-- TOC entry 3613 (class 0 OID 0)
-- Dependencies: 218
-- Name: duenio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.duenio_id_seq OWNED BY public.duenio.id;


--
-- TOC entry 215 (class 1259 OID 16461)
-- Name: perro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.perro (
    id integer NOT NULL,
    nombre character varying(255),
    raza character varying(255),
    color character varying(255),
    duenio_id integer,
    edad integer
);


ALTER TABLE public.perro OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 16460)
-- Name: perro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.perro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.perro_id_seq OWNER TO postgres;

--
-- TOC entry 3614 (class 0 OID 0)
-- Dependencies: 214
-- Name: perro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.perro_id_seq OWNED BY public.perro.id;


--
-- TOC entry 217 (class 1259 OID 16470)
-- Name: vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vacuna (
    id integer NOT NULL,
    fecha date,
    perro_id integer,
    nombrevacuna character varying(255)
);


ALTER TABLE public.vacuna OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16469)
-- Name: vacuna_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vacuna_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vacuna_id_seq OWNER TO postgres;

--
-- TOC entry 3615 (class 0 OID 0)
-- Dependencies: 216
-- Name: vacuna_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vacuna_id_seq OWNED BY public.vacuna.id;


--
-- TOC entry 3451 (class 2604 OID 16480)
-- Name: duenio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.duenio ALTER COLUMN id SET DEFAULT nextval('public.duenio_id_seq'::regclass);


--
-- TOC entry 3449 (class 2604 OID 16464)
-- Name: perro id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro ALTER COLUMN id SET DEFAULT nextval('public.perro_id_seq'::regclass);


--
-- TOC entry 3450 (class 2604 OID 16473)
-- Name: vacuna id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna ALTER COLUMN id SET DEFAULT nextval('public.vacuna_id_seq'::regclass);


--
-- TOC entry 3607 (class 0 OID 16477)
-- Dependencies: 219
-- Data for Name: duenio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.duenio (id, nombre, edad, sexo) FROM stdin;
11	Pedro	30	Masculino
12	Diego	28	Masculino
13	Alejandro	35	Masculino
14	Carolina	40	Femenino
15	Felipe	27	Masculino
\.


--
-- TOC entry 3603 (class 0 OID 16461)
-- Dependencies: 215
-- Data for Name: perro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.perro (id, nombre, raza, color, duenio_id, edad) FROM stdin;
11	Firulais	Labrador	Dorado	11	3
12	Mila	Poodle	Blanco	12	2
13	Chanchito	Bulldog	Marrón	13	4
14	Pelusa	Beagle	Tricolor	14	1
15	Negro	Chihuahua	Café	15	5
\.


--
-- TOC entry 3605 (class 0 OID 16470)
-- Dependencies: 217
-- Data for Name: vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vacuna (id, fecha, perro_id, nombrevacuna) FROM stdin;
6	2020-03-15	11	Triple Felina
7	2020-05-10	13	Coronavirus
8	2020-04-28	12	Síndrome Respiratorio
9	2020-06-15	15	Leptospirosis
10	2020-05-20	14	Parvovirus
\.


--
-- TOC entry 3616 (class 0 OID 0)
-- Dependencies: 218
-- Name: duenio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.duenio_id_seq', 15, true);


--
-- TOC entry 3617 (class 0 OID 0)
-- Dependencies: 214
-- Name: perro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.perro_id_seq', 15, true);


--
-- TOC entry 3618 (class 0 OID 0)
-- Dependencies: 216
-- Name: vacuna_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vacuna_id_seq', 10, true);


--
-- TOC entry 3457 (class 2606 OID 16482)
-- Name: duenio duenio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.duenio
    ADD CONSTRAINT duenio_pkey PRIMARY KEY (id);


--
-- TOC entry 3453 (class 2606 OID 16468)
-- Name: perro perro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro
    ADD CONSTRAINT perro_pkey PRIMARY KEY (id);


--
-- TOC entry 3455 (class 2606 OID 16475)
-- Name: vacuna vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT vacuna_pkey PRIMARY KEY (id);


--
-- TOC entry 3458 (class 2606 OID 16483)
-- Name: perro perro_id_dueno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro
    ADD CONSTRAINT perro_id_dueno_fkey FOREIGN KEY (duenio_id) REFERENCES public.duenio(id);


--
-- TOC entry 3459 (class 2606 OID 16488)
-- Name: vacuna perro_id_vacuna_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT perro_id_vacuna_fkey FOREIGN KEY (perro_id) REFERENCES public.perro(id);


-- Completed on 2023-08-14 23:53:44 -04

--
-- PostgreSQL database dump complete
--

