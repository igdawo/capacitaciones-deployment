--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Dogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Dogs" (
    id integer NOT NULL,
    "Edad" integer NOT NULL,
    "Nombre" character varying NOT NULL,
    "Raza" character varying NOT NULL,
    "Color" character varying NOT NULL,
    "fkdueño" integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public."Dogs" OWNER TO postgres;

--
-- Name: Dogs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Dogs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Dogs_id_seq" OWNER TO postgres;

--
-- Name: Dogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Dogs_id_seq" OWNED BY public."Dogs".id;


--
-- Name: Owners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Owners" (
    id integer NOT NULL,
    "Edad" integer NOT NULL,
    "Nombre" character varying NOT NULL,
    "Sexo" character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public."Owners" OWNER TO postgres;

--
-- Name: Owners_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Owners_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Owners_id_seq" OWNER TO postgres;

--
-- Name: Owners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Owners_id_seq" OWNED BY public."Owners".id;


--
-- Name: Vaccines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Vaccines" (
    id integer NOT NULL,
    "Fecha" date NOT NULL,
    "NombreVacuna" character varying NOT NULL,
    fkperro integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public."Vaccines" OWNER TO postgres;

--
-- Name: Vaccines_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Vaccines_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Vaccines_id_seq" OWNER TO postgres;

--
-- Name: Vaccines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Vaccines_id_seq" OWNED BY public."Vaccines".id;


--
-- Name: Dogs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Dogs" ALTER COLUMN id SET DEFAULT nextval('public."Dogs_id_seq"'::regclass);


--
-- Name: Owners id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Owners" ALTER COLUMN id SET DEFAULT nextval('public."Owners_id_seq"'::regclass);


--
-- Name: Vaccines id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vaccines" ALTER COLUMN id SET DEFAULT nextval('public."Vaccines_id_seq"'::regclass);


--
-- Data for Name: Dogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Dogs" (id, "Edad", "Nombre", "Raza", "Color", "fkdueño", created_at, updated_at, deleted_at) FROM stdin;
0	3	Negrita	Kiltro	Negro	0	2023-08-28 20:35:55.006504	2023-08-28 20:35:55.006504	\N
1	3	Negrita	Kiltro	Negro	0	2023-08-28 20:37:01.137453	2023-08-28 20:37:01.137453	\N
9	4	Hallie	Kiltro		0	2023-08-28 22:54:24.947801	2023-08-28 22:54:24.947801	\N
\.


--
-- Data for Name: Owners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Owners" (id, "Edad", "Nombre", "Sexo", created_at, updated_at, deleted_at) FROM stdin;
0	25	Felipe	Masculino	2023-08-29 09:35:45.123456	2023-08-29 09:35:45.123456	\N
1	26	Ana	Femenino	2023-08-28 22:52:12.966391	2023-08-28 22:52:12.966391	\N
\.


--
-- Data for Name: Vaccines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Vaccines" (id, "Fecha", "NombreVacuna", fkperro, created_at, updated_at, deleted_at) FROM stdin;
1	2023-08-28	RRNN	0	2023-08-28 22:53:41.229725	2023-08-28 22:53:41.229725	\N
\.


--
-- Name: Dogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Dogs_id_seq"', 9, true);


--
-- Name: Owners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Owners_id_seq"', 1, true);


--
-- Name: Vaccines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Vaccines_id_seq"', 1, true);


--
-- Name: Dogs Dogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Dogs"
    ADD CONSTRAINT "Dogs_pkey" PRIMARY KEY (id);


--
-- Name: Owners Owners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Owners"
    ADD CONSTRAINT "Owners_pkey" PRIMARY KEY (id);


--
-- Name: Vaccines Vaccines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vaccines"
    ADD CONSTRAINT "Vaccines_pkey" PRIMARY KEY (id);


--
-- Name: Dogs Dogs_fk-Dueño_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Dogs"
    ADD CONSTRAINT "Dogs_fk-Dueño_fkey" FOREIGN KEY ("fkdueño") REFERENCES public."Owners"(id) NOT VALID;


--
-- Name: Vaccines Vaccines_fk-Perro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vaccines"
    ADD CONSTRAINT "Vaccines_fk-Perro_fkey" FOREIGN KEY (fkperro) REFERENCES public."Dogs"(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

