--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dueno; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dueno (
    id integer NOT NULL,
    nombre character varying,
    edad integer,
    sexo character varying
);


ALTER TABLE public.dueno OWNER TO postgres;

--
-- Name: perro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.perro (
    id integer NOT NULL,
    nombre character varying,
    raza character varying,
    color character varying,
    edad integer,
    id_dueno integer
);


ALTER TABLE public.perro OWNER TO postgres;

--
-- Name: vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vacuna (
    id integer NOT NULL,
    fecha date,
    nombre_vacuna character varying,
    id_perro integer
);


ALTER TABLE public.vacuna OWNER TO postgres;

--
-- Data for Name: dueno; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dueno (id, nombre, edad, sexo) FROM stdin;
0	Héctor	22	Masculino
1	Marcela	50	Femenino
2	Génesis	29	Femenino
3	Krichna	22	Femenino
4	Juán	84	Masculino
\.


--
-- Data for Name: perro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.perro (id, nombre, raza, color, edad, id_dueno) FROM stdin;
0	Luka	Quiltro	Negro	11	0
1	Gaspy	Poodle	Negro	7	1
2	Pancha	Quiltro	Blanco	14	3
3	Dogo	Poodle	Negro	3	2
4	Chiruca	Quiltro	Café	15	4
\.


--
-- Data for Name: vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vacuna (id, fecha, nombre_vacuna, id_perro) FROM stdin;
0	2023-08-05	Rabia	2
1	2023-08-06	Parvovirus	0
2	2023-08-08	Moquillo	3
3	2023-08-10	Hepatitis	1
4	2023-08-11	Leptospirosis	4
\.


--
-- Name: dueno dueno_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dueno
    ADD CONSTRAINT dueno_pkey PRIMARY KEY (id);


--
-- Name: perro perro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro
    ADD CONSTRAINT perro_pkey PRIMARY KEY (id);


--
-- Name: vacuna vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT vacuna_pkey PRIMARY KEY (id);


--
-- Name: perro perro_id_dueno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro
    ADD CONSTRAINT perro_id_dueno_fkey FOREIGN KEY (id_dueno) REFERENCES public.dueno(id);


--
-- Name: vacuna vacuna_id_perro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT vacuna_id_perro_fkey FOREIGN KEY (id_perro) REFERENCES public.perro(id);


--
-- PostgreSQL database dump complete
--

