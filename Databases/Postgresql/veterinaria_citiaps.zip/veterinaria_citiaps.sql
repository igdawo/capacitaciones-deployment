--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dueno; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dueno (
    _id integer NOT NULL,
    nombre character varying,
    edad integer,
    sexo character varying
);


ALTER TABLE public.dueno OWNER TO postgres;

--
-- Name: dueno_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dueno_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dueno_id_seq OWNER TO postgres;

--
-- Name: dueno_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dueno_id_seq OWNED BY public.dueno._id;


--
-- Name: perro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.perro (
    _id integer NOT NULL,
    nombre character varying,
    raza character varying,
    color character varying,
    edad integer,
    id_dueno integer
);


ALTER TABLE public.perro OWNER TO postgres;

--
-- Name: perro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.perro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.perro_id_seq OWNER TO postgres;

--
-- Name: perro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.perro_id_seq OWNED BY public.perro._id;


--
-- Name: vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vacuna (
    _id integer NOT NULL,
    fecha date,
    nombre_vacuna character varying,
    id_perro integer
);


ALTER TABLE public.vacuna OWNER TO postgres;

--
-- Name: vacuna_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vacuna_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vacuna_id_seq OWNER TO postgres;

--
-- Name: vacuna_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vacuna_id_seq OWNED BY public.vacuna._id;


--
-- Name: dueno _id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dueno ALTER COLUMN _id SET DEFAULT nextval('public.dueno_id_seq'::regclass);


--
-- Name: perro _id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro ALTER COLUMN _id SET DEFAULT nextval('public.perro_id_seq'::regclass);


--
-- Name: vacuna _id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna ALTER COLUMN _id SET DEFAULT nextval('public.vacuna_id_seq'::regclass);


--
-- Data for Name: dueno; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dueno (_id, nombre, edad, sexo) FROM stdin;
1	Héctor	22	Masculino
2	Marcela	50	Femenino
3	Génesis	29	Femenino
4	Krichna	22	Femenino
5	Juán	84	Masculino
6	Patricia	60	Femenino
7	Ana	70	Femenino
\.


--
-- Data for Name: perro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.perro (_id, nombre, raza, color, edad, id_dueno) FROM stdin;
1	Luka	Quiltro	Negro	11	1
2	Gaspy	Poodle	Negro	7	2
3	Pancha	Quiltro	Blanco	14	4
4	Dogo	Poodle	Negro	3	3
15	Chilín	Quiltro	Café	9	7
16	Tomy	Salchicha	Blanco	1	6
\.


--
-- Data for Name: vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vacuna (_id, fecha, nombre_vacuna, id_perro) FROM stdin;
1	2023-08-05	Rabia	3
2	2023-08-06	Parvovirus	1
3	2023-08-08	Moquillo	4
4	2023-08-10	Hepatitis	2
5	2023-08-11	Leptospirosis	5
6	2023-08-21	Rabia	13
7	2023-08-21	Rabia	15
8	2023-08-21	Hepatitis	1
9	2023-08-21	Rabia	1
\.


--
-- Name: dueno_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dueno_id_seq', 7, true);


--
-- Name: perro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.perro_id_seq', 16, true);


--
-- Name: vacuna_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vacuna_id_seq', 9, true);


--
-- Name: dueno dueno_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dueno
    ADD CONSTRAINT dueno_pkey PRIMARY KEY (_id);


--
-- Name: perro perro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro
    ADD CONSTRAINT perro_pkey PRIMARY KEY (_id);


--
-- Name: vacuna vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT vacuna_pkey PRIMARY KEY (_id);


--
-- PostgreSQL database dump complete
--

