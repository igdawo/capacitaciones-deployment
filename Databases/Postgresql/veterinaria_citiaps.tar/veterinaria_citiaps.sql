--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dueno; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dueno (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    edad integer NOT NULL,
    sexo character varying(255) NOT NULL
);


ALTER TABLE public.dueno OWNER TO postgres;

--
-- Name: dueno_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dueno_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dueno_id_seq OWNER TO postgres;

--
-- Name: dueno_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dueno_id_seq OWNED BY public.dueno.id;


--
-- Name: perro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.perro (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    raza character varying(255) NOT NULL,
    color character varying(255) NOT NULL,
    edad integer NOT NULL,
    dueno_id integer NOT NULL
);


ALTER TABLE public.perro OWNER TO postgres;

--
-- Name: perro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.perro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.perro_id_seq OWNER TO postgres;

--
-- Name: perro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.perro_id_seq OWNED BY public.perro.id;


--
-- Name: vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vacuna (
    id integer NOT NULL,
    fecha date NOT NULL,
    nombre character varying(255) NOT NULL,
    perro_id integer NOT NULL
);


ALTER TABLE public.vacuna OWNER TO postgres;

--
-- Name: vacuna_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vacuna_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vacuna_id_seq OWNER TO postgres;

--
-- Name: vacuna_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vacuna_id_seq OWNED BY public.vacuna.id;


--
-- Name: dueno id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dueno ALTER COLUMN id SET DEFAULT nextval('public.dueno_id_seq'::regclass);


--
-- Name: perro id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro ALTER COLUMN id SET DEFAULT nextval('public.perro_id_seq'::regclass);


--
-- Name: vacuna id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna ALTER COLUMN id SET DEFAULT nextval('public.vacuna_id_seq'::regclass);


--
-- Data for Name: dueno; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dueno (id, nombre, edad, sexo) FROM stdin;
1	gabriel garcia	23	masculino
2	juan gallardo	32	masculino
3	javiera mancilla	25	femenino
4	oliver olivera	22	masculino
5	barbara alvarez	27	femenino
\.


--
-- Data for Name: perro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.perro (id, nombre, raza, color, edad, dueno_id) FROM stdin;
1	pelusa	caniche	cafe	3	1
2	cafe	yorkshire	cafe	4	2
3	puntos	dalmata	blanco	2	3
4	mili	beagle	cafe	6	3
5	pitufo	chihuaha	cafe	5	4
6	clifford	caniche	blanco	9	5
\.


--
-- Data for Name: vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vacuna (id, fecha, nombre, perro_id) FROM stdin;
1	2022-03-12	rabia	1
2	2023-03-03	rabia	2
3	2021-02-05	moquillo	2
4	2022-03-30	moquillo	3
5	2022-05-10	parvovirosis	4
6	2023-07-20	parvovirosis	5
7	2019-01-19	rabia	6
\.


--
-- Name: dueno_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dueno_id_seq', 5, true);


--
-- Name: perro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.perro_id_seq', 6, true);


--
-- Name: vacuna_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vacuna_id_seq', 7, true);


--
-- Name: dueno dueno_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dueno
    ADD CONSTRAINT dueno_pkey PRIMARY KEY (id);


--
-- Name: perro perro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro
    ADD CONSTRAINT perro_pkey PRIMARY KEY (id);


--
-- Name: vacuna vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT vacuna_pkey PRIMARY KEY (id);


--
-- Name: perro perro_dueno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perro
    ADD CONSTRAINT perro_dueno_id_fkey FOREIGN KEY (dueno_id) REFERENCES public.dueno(id);


--
-- Name: vacuna vacuna_perro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT vacuna_perro_id_fkey FOREIGN KEY (perro_id) REFERENCES public.perro(id);


--
-- PostgreSQL database dump complete
--

