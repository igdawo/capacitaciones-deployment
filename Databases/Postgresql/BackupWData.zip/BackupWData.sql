--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Dueño; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Dueño" (
    id integer NOT NULL,
    "Nombre" text,
    "Edad" integer,
    "Sexo" text
);


ALTER TABLE public."Dueño" OWNER TO postgres;

--
-- Name: Perro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Perro" (
    id integer NOT NULL,
    "Nombre" text,
    "Raza" text,
    "Color" text,
    "Edad" integer,
    "Dueño" integer
);


ALTER TABLE public."Perro" OWNER TO postgres;

--
-- Name: Vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Vacuna" (
    id integer NOT NULL,
    "Fecha" date,
    "NombreVacuna" text,
    "Perro" integer
);


ALTER TABLE public."Vacuna" OWNER TO postgres;

--
-- Data for Name: Dueño; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Dueño" (id, "Nombre", "Edad", "Sexo") FROM stdin;
1	Mia Robinson	14	Femenino
2	Rigoberto Ruiztagle	22	Masculino
3	Albertio Villalobos	24	Masculino
4	Pia Croxato	28	Femenino
5	Bender Blade	44	Masculino
\.


--
-- Data for Name: Perro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Perro" (id, "Nombre", "Raza", "Color", "Edad", "Dueño") FROM stdin;
1	Godofredo	French Poodle	Blanco	2	2
2	Pantufla	Yorkshire	Gris	1	1
3	Princesa	Pitbull	Café	6	4
4	Calcetín	Quilterrier	Blanco	4	3
5	Zeus	Chihuahua	Negro	3	5
\.


--
-- Data for Name: Vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Vacuna" (id, "Fecha", "NombreVacuna", "Perro") FROM stdin;
1	2023-12-02	Octuple	3
2	2023-11-28	Octuple	1
3	2023-12-02	Anti-rabica	5
4	2023-12-03	Octuple	4
5	2023-12-30	Anti-rabica	2
\.


--
-- Name: Dueño Dueño_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Dueño"
    ADD CONSTRAINT "Dueño_pkey" PRIMARY KEY (id);


--
-- Name: Perro Perro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Perro"
    ADD CONSTRAINT "Perro_pkey" PRIMARY KEY (id);


--
-- Name: Vacuna Vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vacuna"
    ADD CONSTRAINT "Vacuna_pkey" PRIMARY KEY (id);


--
-- Name: Perro FK_DueñoPerro; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Perro"
    ADD CONSTRAINT "FK_DueñoPerro" FOREIGN KEY ("Dueño") REFERENCES public."Dueño"(id) NOT VALID;


--
-- Name: Vacuna FK_VacunaDelPerro; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vacuna"
    ADD CONSTRAINT "FK_VacunaDelPerro" FOREIGN KEY ("Perro") REFERENCES public."Perro"(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

